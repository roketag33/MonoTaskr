import{B as S,s as o,T as b,M as v}from"./messaging-BvRl8-V2.js";console.log("MonoTaskr content script loaded.");let f=[],h=[],u={},g=S.BLACKLIST,c=!1,d=null;function k(e){return u[e]&&u[e]>Date.now()?!1:g===S.BLACKLIST?f.some(r=>e.includes(r)):e?!h.some(a=>e.includes(a)):!1}function m(e,r){const a=c;c=k(e),a!==c&&o.getTimerState().then(n=>{r(n)})}function x(){let e=null;const r=()=>{const n=document.createElement("div");n.id="monotaskr-overlay-container";const l=n.attachShadow({mode:"closed"}),i=document.createElement("style");i.textContent=`
      :host {
        all: initial;
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2147483647;
      }
      .overlay {
        width: 100%;
        height: 100%;
        background-color: #e74c3c; /* Angry Red */
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        font-family: 'Comic Sans MS', 'Chalkboard SE', sans-serif;
        color: white;
        text-align: center;
        user-select: none;
      }
      .content {
        animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
        transform: translate3d(0, 0, 0);
        backface-visibility: hidden;
        perspective: 1000px;
      }
      h1 {
        font-size: 5rem;
        margin: 0;
        text-transform: uppercase;
        text-shadow: 4px 4px 0px #c0392b;
      }
      .emoji {
        font-size: 8rem;
        margin-bottom: 2rem;
      }
      p {
        font-size: 2rem;
        margin-top: 1rem;
        font-weight: bold;
      }
      @keyframes shake {
        10%, 90% { transform: translate3d(-1px, 0, 0); }
        20%, 80% { transform: translate3d(2px, 0, 0); }
        30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
        40%, 60% { transform: translate3d(4px, 0, 0); }
      }
    `;const s=document.createElement("div");s.className="overlay",s.innerHTML=`
      <div class="content">
        <div class="emoji">😠</div>
        <h1>NON !</h1>
        <p>Tu devrais être en train de travailler !</p>
        <p>Ferme cet onglet tout de suite.</p>
        <button id="btn-temp-access" style="
            margin-top: 2rem;
            padding: 10px 20px;
            font-size: 1.2rem;
            background: transparent;
            border: 2px solid white;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
        ">J'en ai besoin pour 1 min 🥺</button>
        <p id="temp-error" style="font-size: 1rem; color: yellow; display: none;"></p>
      </div>
    `;const t=s.querySelector("#btn-temp-access"),y=s.querySelector("#temp-error");return t.addEventListener("click",async()=>{t.disabled=!0,t.textContent="Vérification...";try{const p=await chrome.runtime.sendMessage({type:v.REQUEST_TEMP_ACCESS,payload:{domain:window.location.hostname}});p&&p.authorized?t.textContent="Autorisé !":(t.textContent="Refusé",y.textContent="Limite journalière atteinte !",y.style.display="block",setTimeout(()=>{t.disabled=!1,t.textContent="J'en ai besoin pour 1 min 🥺"},3e3))}catch{t.textContent="Erreur",t.disabled=!1}}),l.appendChild(i),l.appendChild(s),n};return n=>{n&&((n.status===b.RUNNING||n.status===b.SCHEDULED)&&c?e||(e=r(),document.body?(document.body.appendChild(e),document.body.style.overflow="hidden"):(document.documentElement.appendChild(e),document.documentElement.style.overflow="hidden")):e&&(e.remove(),e=null,document.body&&(document.body.style.overflow=""),document.documentElement.style.overflow=""))}}(async()=>{const[e,r,a,n]=await Promise.all([o.getBlockedSites(),o.getWhitelistedSites(),o.getBlockingMode(),o.getTempOverrides()]);f=e,h=r,g=a,u=n||{};const l=window.location.hostname;c=k(l);const i=x(),s=await o.getTimerState();i(s),o.onTimerStateChanged(i),o.onBlockedSitesChanged(t=>{f=t,m(l,i)}),o.onWhitelistedSitesChanged(t=>{h=t,m(l,i)}),o.onBlockingModeChanged(t=>{g=t,m(l,i)}),o.onTempOverridesChanged(t=>{u=t||{},m(l,i)})})();chrome.runtime.onMessage.addListener(e=>{e.action==="UPDATE_TITLE"&&e.title?(d===null&&(d=document.title),document.title=e.title):e.action==="RESET_TITLE"&&d!==null&&(document.title=d,d=null)});
